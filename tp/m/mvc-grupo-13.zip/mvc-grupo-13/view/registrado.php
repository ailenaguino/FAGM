{{> headerLogeado}}
<div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">
    {{#sesion}}
    <h2 class="w3-wide">{{name}} quiere ser parte de la banda!</h2>
    <table class="w3-table">
        Actualmente utiliza {{pass}} como pass.
    </table>
    {{/sesion}}
</div>
{{> footer}}

